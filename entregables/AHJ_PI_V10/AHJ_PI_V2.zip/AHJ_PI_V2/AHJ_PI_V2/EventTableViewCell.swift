//
//  EventTableViewCell.swift
//  AHJ_PI_V2
//
//  Created by JonathanA on 29/12/22.
//

import UIKit

class EventTableViewCell: UITableViewCell {
    @IBOutlet weak var color: UILabel!
    @IBOutlet weak var eventTitle: UILabel!
    @IBOutlet weak var startDate: UILabel!
    @IBOutlet weak var endDate: UILabel!
}
