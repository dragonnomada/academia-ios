//
//  EventViewModel.swift
//  AHJ_PI_V2
//
//  Created by JonathanA on 27/12/22.
//

import Foundation
import Combine

class EventViewModel {
    
}
