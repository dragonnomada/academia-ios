//
//  FoodRouter.swift
//  HomeModule
//
//  Created by User on 27/01/23.
//

import Foundation
import UIKit

class HomeModuleRouter {
    
    internal lazy var navigationController: UINavigationController = {
        
        let navigationController = UINavigationController()
        
        return navigationController
        
    }()
    
}
